"""定义各种求解器中的激励源和端口。"""

from . import hf
