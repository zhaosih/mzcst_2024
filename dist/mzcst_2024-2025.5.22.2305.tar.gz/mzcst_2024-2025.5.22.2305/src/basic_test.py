import mzcst_2024 as mz

if __name__ == "__main__":
    # This is a demo script to show how to use mzcst
    print(mz.__version__)
    print(mz.__file__)   
    pass
